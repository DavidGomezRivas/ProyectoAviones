package com.company.room;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.company.room.databinding.FragmentRecyclerElementosBinding;
import com.company.room.databinding.ViewholderElementoBinding;

import java.util.ArrayList;
import java.util.List;


public class RecyclerElementosFragment extends Fragment {
    ElementosAdapter elementosAdapter;
    private FragmentRecyclerElementosBinding binding;
    ElementosViewModel elementosViewModel;
    private NavController navController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRecyclerElementosBinding.inflate(inflater, container, false);
        RecyclerView recyclerView = binding.recyclerView;
        elementosAdapter = new ElementosAdapter();
        binding.recyclerView.setAdapter(elementosAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        elementosViewModel = new ViewModelProvider(requireActivity()).get(ElementosViewModel.class);
        navController = Navigation.findNavController(view);
        new ConnectToDatabaseTask().execute();
        binding.recyclerView.addItemDecoration(new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL));
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, ItemTouchHelper.RIGHT | ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return true;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int posicion = viewHolder.getAdapterPosition();
                Elemento elementos = elementosAdapter.obtenerElemento(posicion);
                elementosViewModel.eliminar(elementos);
            }
        }).attachToRecyclerView(binding.recyclerView);

        obtenerElementos().observe(getViewLifecycleOwner(), new Observer<List<Elemento>>() {
            @Override
            public void onChanged(List<Elemento> Elemento) {
                elementosAdapter.establecerLista(Elemento);
            }
        });
    }

    LiveData<List<Elemento>> obtenerElementos() {
        return elementosViewModel.obtener();
    }

    class ElementosAdapter extends RecyclerView.Adapter<ElementoViewHolder> {
        List<Elemento> elementos;

        @NonNull
        @Override
        public ElementoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ElementoViewHolder(ViewholderElementoBinding.inflate(getLayoutInflater(), parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull ElementoViewHolder holder, int position) {
            Elemento elemento = elementos.get(position);
            holder.plane.setText(elemento.getPlane());
            holder.brand.setText(elemento.getBrand());
            Glide.with(requireContext()).load(elemento.imgThumb).into(holder.imgThumb);
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    elementosViewModel.seleccionar(elemento);
                    navController.navigate(R.id.action_mostrarElementoFragment);
                }
            });
        }

        @Override
        public int getItemCount() {
            return elementos != null ? elementos.size() : 0;
        }

        public void establecerLista(List<Elemento> Elemento) {
            this.elementos = Elemento;
            notifyDataSetChanged();
        }

        public Elemento obtenerElemento(int posicion) {
            return elementos.get(posicion);
        }
    }

    static class ElementoViewHolder extends RecyclerView.ViewHolder {
        private final ViewholderElementoBinding binding;
        TextView plane;
        ImageView imgThumb;
        TextView brand;
        public ElementoViewHolder(ViewholderElementoBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
            imgThumb = itemView.findViewById(R.id.imgThumb);
            plane = itemView.findViewById(R.id.plane);
            brand = itemView.findViewById(R.id.brand);
        }
    }

    public void setElementoList(ArrayList<Elemento> elementoLis) {
        if (elementosAdapter != null) {
            elementosAdapter.establecerLista(elementoLis);
        }
    }

    public void cargarDatosDesdeBaseDeDatos(ArrayList<Elemento> elementoList) {
        // Actualiza el adaptador con la nueva lista de series
        setElementoList(elementoList);

    }

    private class ConnectToDatabaseTask extends AsyncTask<Void, Void, ArrayList<Elemento>> {
        @Override
        protected ArrayList<Elemento> doInBackground(Void... voids) {
            ConexionDB conexionDB = new ConexionDB();
            conexionDB.conexionOpen();
            return conexionDB.mostrarTabla("SELECT * FROM aviones");
        }

        @Override
        protected void onPostExecute(ArrayList<Elemento> elementoList) {
            if (elementoList != null) {
                // Actualizar el adaptador con la nueva lista de series
                cargarDatosDesdeBaseDeDatos(elementoList);

            } else {
                // Maneja el caso en que la conexión no se pudo establecer
                Toast.makeText(requireActivity(), "No se pudo conectar a la base de datos", Toast.LENGTH_SHORT).show();
            }
        }
    }
}