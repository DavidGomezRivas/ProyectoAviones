package com.company.room;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Elemento")
public class Elemento {
    @PrimaryKey(autoGenerate = true)
    int id;
    String plane;
    String brand;
    int passengerCapacity;
    int fuelCapacityLitres;
    int maxTakeoffWeightKg;
    int maxLandingWeightKg;
    int emptyWeightKg;
    int rangeKm;
    String engine;
    int cruiseSpeedKmph;
    String imgThumb;

    public Elemento(int id, String plane, String brand, int passengerCapacity, int fuelCapacityLitres, int maxTakeoffWeightKg, int maxLandingWeightKg, int emptyWeightKg, int rangeKm, String engine, int cruiseSpeedKmph, String imgThumb) {
        this.id = id;
        this.plane = plane;
        this.brand = brand;
        this.passengerCapacity = passengerCapacity;
        this.fuelCapacityLitres = fuelCapacityLitres;
        this.maxTakeoffWeightKg = maxTakeoffWeightKg;
        this.maxLandingWeightKg = maxLandingWeightKg;
        this.emptyWeightKg = emptyWeightKg;
        this.rangeKm = rangeKm;
        this.engine = engine;
        this.cruiseSpeedKmph = cruiseSpeedKmph;
        this.imgThumb = imgThumb;
    }

    public int getId() {
        return id;
    }

    public String getPlane() {
        return plane;
    }

    public String getBrand() {
        return brand;
    }

    public int getPassengerCapacity() {
        return passengerCapacity;
    }

    public int getFuelCapacityLitres() {
        return fuelCapacityLitres;
    }

    public int getMaxTakeoffWeightKg() {
        return maxTakeoffWeightKg;
    }

    public int getMaxLandingWeightKg() {
        return maxLandingWeightKg;
    }

    public int getEmptyWeightKg() {
        return emptyWeightKg;
    }

    public int getRangeKm() {
        return rangeKm;
    }

    public String getEngine() {
        return engine;
    }

    public int getCruiseSpeedKmph() {
        return cruiseSpeedKmph;
    }

    public String getImgThumb() {
        return imgThumb;
    }
}
