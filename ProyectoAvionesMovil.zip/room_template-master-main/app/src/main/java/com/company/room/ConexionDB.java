package com.company.room;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
public class ConexionDB {
        private Connection con;
        private Statement st;
        private ResultSet rs;
        public Connection conexionOpen() {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
                String url = "jdbc:mysql://monorail.proxy.rlwy.net:15847/";
                String usuario = "root";
                String contraseña = "-E3B6F3b-d5gAbchEbGFfBhdd6eCCH2e";
                String dbName = "railway";
                con = DriverManager.getConnection(url+dbName, usuario, contraseña);
                if (con != null) {
                    System.out.println("Conexión exitosa a la base de datos MySQL.");
                }
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println("ERROR: " + e.getMessage());
                e.printStackTrace();
            } catch (IllegalAccessException | InstantiationException e) {
                throw new RuntimeException(e);
            }
            return con;
        }
        public ArrayList<Elemento> mostrarTabla(String consulta) {
            ArrayList<Elemento> seriesList = new ArrayList<>();
            try {
                st = con.createStatement();
                rs = st.executeQuery(consulta);
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String plane = rs.getString("plane");
                    String brand = rs.getString("brand");
                    int passenger_capacity = rs.getInt("passenger_capacity");
                    int fuel_capacity_litres = rs.getInt("fuel_capacity_litres");
                    int max_takeoff_weight_kg = rs.getInt("max_takeoff_weight_kg");
                    int max_landing_weight_kg = rs.getInt("passenger_capacity");
                    int empty_weight_kg = rs.getInt("empty_weight_kg");
                    int range_km = rs.getInt("range_km");
                    String engine = rs.getString("engine");
                    int cruise_speed_kmph = rs.getInt("cruise_speed_kmph");
                    String imgThumb = rs.getString("imgThumb");

                    Elemento Elemento = new Elemento(id, plane, brand, passenger_capacity, fuel_capacity_litres, max_takeoff_weight_kg, max_landing_weight_kg, empty_weight_kg, range_km, engine,cruise_speed_kmph, imgThumb);
                    seriesList.add(Elemento);
                }
                cerrarConexion();
            } catch (Exception e) {
                System.out.println("ERROR: " + e.getMessage());
            }
            return seriesList;
        }
        private void cerrarConexion() {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                System.out.println("ERROR al cerrar la conexión: " + e.getMessage());
            }
        }
    }
